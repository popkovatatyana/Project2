from flask import Flask
from flask import url_for, render_template, request, redirect
import json, re

app = Flask(__name__)

@app.route('/')
def main_page():
    return render_template('page1.html')

@app.route('/thanks')
def thanks():
    global s
    d={}
    i=0
    d['Из какого Вы города?'] = request.args['city']
    d['Что для вас значит "Я не отразил(а)?']= request.args['menu1']
    if request.args['menu2'] == 'Свой вариант':
        d['Продолжите высказывание: "Жадина-говядина..."']= request.args['input1']
    else:
        d['Продолжите высказывание: "Жадина-говядина..."']= request.args['menu2']
    d['Как  называется этот предмет?']= request.args['menu3']
    d['Знаете ли Вы, что означает слово "айбол?"']= request.args['menu4']
    d['Знаете ли Вы, что означает выражение "двигать пары"?']= request.args['menu5']
    d['Как называется  этот предмет?']= request.args['menu6']
    if request.args['menu7'] == 'Свой вариант':
        d['Как называется этот предмет? ']= request.args['input2']
    else:
        d['Как называется этот предмет? ']= request.args['menu7']
    if request.args['menu8'] == 'Свой вариант':
        d['Как называется игра, когда один игрок догоняет других и, посредством тактильного прикосновения, передает статус "догоняющего"?']= request.args['input3']
    else:
        d['Как называется игра, когда один игрок догоняет других и, посредством тактильного прикосновения, передает статус "догоняющего"?']= request.args['menu8']
    if request.args['menu9'] == 'Свой вариант':
        d['Как называется в этом случае "догоняющий" игрок?']= request.args['input4']
    else:
        d['Как называется в этом случае "догоняющий" игрок?']= request.args['menu9']
    s = json.dumps(d, sort_keys=True, indent=4, separators=(',', ': '), ensure_ascii = False)
    file = open('mydata.txt', "w", encoding = "utf-8")
    file.write(s)
    file.close()
    file = open('alldata.txt', "a", encoding = "utf-8")
    file.write(s+'\n')
    file.close()
    if request.args['menu1'] == 'Не понял(а)':
        i+=1
    else:
        i=i
    if request.args['menu2'] == 'Пустая шоколадина':
        i+=1
    else:
        i=i
    if request.args['menu3'] == 'Бирка':
        i+=1
    else:
        i=i
    if request.args['menu4'] == 'Да':
        i+=1
    else:
        i=i
    if request.args['menu5'] == 'Прогуливать пары':
        i+=1
    else:
        i=i
    if request.args['menu6'] == 'Вехотка':
        i+=1
    else:
        i=i
    if request.args['menu7'] == 'Штрих':
        i+=1
    else:
        i=i
    if request.args['menu8'] == 'Ляпки':
        i+=1
    else:
        i=i
    if request.args['menu9'] == 'Галя':
        i+=1
    else:
        i=i
    total= int(i/9*100)    
    return render_template('thanks.html', total = total)

@app.route('/json')
def data():
    file = open('alldata.txt', "r", encoding = "utf-8")
    f = file.read()
    file.close()
    return render_template('total.html', m = f)

@app.route('/myjson')
def data1():
    file = open('mydata.txt', "r", encoding = "utf-8")
    f = file.read()
    file.close()
    return render_template('totalmy.html', m = f)
        
@app.route('/stat')
def pagestat():
    file = open('alldata.txt', "r", encoding = "utf-8")
    f = file.read()
    file.close()
    a=0
    b=0
    c=0
    d=0
    a1=0
    b1=0
    c1=0
    d1=0
    a2=0
    b2=0
    c2=0
    a3=0
    b3=0
    a4=0
    b4=0
    c4=0
    a5=0
    b5=0
    c5=0
    a6=0
    b6=0
    c6=0
    d6=0
    a7=0
    b7=0
    c7=0
    d7=0
    a8=0
    b8=0
    c8=0
    d8=0
    results = re.findall('({.+?})', f, flags=re.DOTALL)
    for result in results:
        result=''.join(result)
        data = json.loads(result)
        for key in data:
            if key == 'Что для вас значит \"Я не отразил(а)?':
                if data[key] == "Ничего":
                    a+=1
                if data[key] =="Не понял(а)":
                    b+=1
                if data[key] == "Я не зеркало":
                    c+=1
                if data[key] == "Не отразил(а) атаку":
                    d+=1
                af= str(a)
                bf=str(b)
                cf=str(c)
                df=str(d)
                
            if key == 'Продолжите высказывание: \"Жадина-говядина...\"':
                if data[key] == "Соленый огурец":
                    a1+=1
                if data[key] == "Турецкий барабан":
                    b1+=1
                if data[key] == "Пустая шоколадина":
                    c1+=1
                if data[key] != "Соленый огурец" and data[key] != "Турецкий барабан" and data[key] != "Пустая шоколадина":
                    d1+=1
                a1f= str(a1)
                b1f=str(b1)
                c1f=str(c1)
                d1f=str(d1)
                
            if key == 'Как  называется этот предмет?':
                if data[key] == "Номерок":
                    a2+=1
                if data[key] =="Бирка":
                    b2+=1
                if data[key] == "Не знаю, что это":
                    c2+=1
                a2f= str(a2)
                b2f=str(b2)
                c2f=str(c2)
                
            if key == 'Знаете ли Вы, что означает слово \"айбол?\"':
                if data[key] == "Нет":
                    a3+=1
                if data[key] =="Да":
                    b3+=1
                a3f= str(a3)
                b3f=str(b3)

            if key == 'Знаете ли Вы, что означает выражение \"двигать пары\"?':
                if data[key] == "Переставлять пары в расписании":
                    a4+=1
                if data[key] =="Прогуливать пары":
                    b4+=1
                if data[key] == "Нет":
                    c4+=1
                a4f=str(a4)
                b4f=str(b4)
                c4f=str(c4)
                
            if key == 'Как называется  этот предмет?':
                if data[key] == "Вехотка":
                    a5+=1
                if data[key] =="Мочалка":
                    b5+=1
                if data[key] == "Не знаю, что это":
                    c5+=1
                a5f= str(a5)
                b5f=str(b5)
                c5f=str(c5)
                
            if key == 'Как называется этот предмет? ':
                if data[key] == "Штрих":
                    a6+=1
                if data[key] == "Замазка":
                    b6+=1
                if data[key] == "Корректор":
                    c6+=1
                if data[key] != "Штрих" and data[key] != "Замазка" and data[key] != "Корректор":
                    d6+=1
                a6f=str(a6)
                b6f=str(b6)
                c6f=str(c6)
                d6f=str(d6)
                
            if key == 'Как называется игра, когда один игрок догоняет других и, посредством тактильного прикосновения, передает статус \"догоняющего\"?':
                if data[key] == "Ляпки":
                    a7+=1
                if data[key] == "Тяпки":
                    b7+=1
                if data[key] == "Догонялки":
                    c7+=1
                if data[key] != "Ляпки" and data[key] != "Тяпки" and data[key] != "Догонялки":
                    d7+=1
                a7f=str(a7)
                b7f=str(b7)
                c7f=str(c7)
                d7f=str(d7)

            if key == 'Как называется в этом случае \"догоняющий\" игрок?':
                if data[key] == "Галя":
                    a8+=1
                if data[key] == "Догоняла":
                    b8+=1
                if data[key] == "Лэм":
                    c8+=1
                if data[key] != "Галя" and data[key] != "Догоняла" and data[key] != "Лэм":
                    d8+=1
                a8f=str(a8)
                b8f=str(b8)
                c8f=str(c8)
                d8f=str(d8)
                
            else:
                continue
        
    return render_template('answers.html', af=af, bf=bf, cf=cf, df=df, a1f=a1f, b1f=b1f, c1f=c1f, d1f=d1f,a2f=a2f, b2f=b2f, \
                           c2f=c2f, a3f=a3f, b3f=b3f, a4f=a4f, b4f=b4f, c4f=c4f, a5f=a5f, b5f=b5f, c5f=c5f, a6f=a6f, b6f=b6f,c6f=c6f, d6f=d6f, \
                           a7f=a7f, b7f=b7f, c7f=c7f, d7f=d7f, a8f=a8f, b8f=b8f, c8f=c8f, d8f=d8f )

@app.route('/search')
def  search():
    file = open('alldata.txt', "r", encoding = "utf-8")
    f = file.read()
    file.close()
    results = re.findall('({.+?})', f, flags=re.DOTALL)
    cities={}
    i=0
    for result in results:
        result=''.join(result)
        data = json.loads(result)
        for key in data:
            if key == "Из какого Вы города?":
                cities[data[key]]=data[key]
    return render_template('search.html', cities = cities)

@app.route('/result')
def result():
    file = open('alldata.txt', "r", encoding = "utf-8")
    f = file.read()
    file.close()
    results = re.findall('({.+?})', f, flags=re.DOTALL)
    arr=[]
    a=0
    b=0
    c=0
    d=0
    a1=0
    b1=0
    c1=0
    d1=0
    a2=0
    b2=0
    c2=0
    a3=0
    b3=0
    a4=0
    b4=0
    c4=0
    a5=0
    b5=0
    c5=0
    a6=0
    b6=0
    c6=0
    d6=0
    a7=0
    b7=0
    c7=0
    d7=0
    a8=0
    b8=0
    c8=0
    d8=0
    for result in results:
        result=''.join(result)
        data = json.loads(result)
        for key in data:
            if key == "Из какого Вы города?":
                  if data[key] == request.args['cityname']:
                        for key in data:
                            if key == 'Что для вас значит \"Я не отразил(а)?':
                                if data[key] == "Ничего":
                                    a+=1
                                if data[key] =="Не понял(а)":
                                    b+=1
                                if data[key] == "Я не зеркало":
                                    c+=1
                                if data[key] == "Не отразил(а) атаку":
                                    d+=1
                                af= str(a)
                                bf=str(b)
                                cf=str(c)
                                df=str(d)
                                
                            if key == 'Продолжите высказывание: \"Жадина-говядина...\"':
                                if data[key] == "Соленый огурец":
                                    a1+=1
                                if data[key] == "Турецкий барабан":
                                    b1+=1
                                if data[key] == "Пустая шоколадина":
                                    c1+=1
                                if data[key] != "Соленый огурец" and data[key] != "Турецкий барабан" and data[key] != "Пустая шоколадина":
                                    d1+=1
                                a1f= str(a1)
                                b1f=str(b1)
                                c1f=str(c1)
                                d1f=str(d1)
                                
                            if key == 'Как  называется этот предмет?':
                                if data[key] == "Номерок":
                                    a2+=1
                                if data[key] =="Бирка":
                                    b2+=1
                                if data[key] == "Не знаю, что это":
                                    c2+=1
                                a2f= str(a2)
                                b2f=str(b2)
                                c2f=str(c2)
                                
                            if key == 'Знаете ли Вы, что означает слово \"айбол?\"':
                                if data[key] == "Нет":
                                    a3+=1
                                if data[key] =="Да":
                                    b3+=1
                                a3f= str(a3)
                                b3f=str(b3)

                            if key == 'Знаете ли Вы, что означает выражение \"двигать пары\"?':
                                if data[key] == "Переставлять пары в расписании":
                                    a4+=1
                                if data[key] =="Прогуливать пары":
                                    b4+=1
                                if data[key] == "Нет":
                                    c4+=1
                                a4f=str(a4)
                                b4f=str(b4)
                                c4f=str(c4)
                                
                            if key == 'Как называется  этот предмет?':
                                if data[key] == "Вехотка":
                                    a5+=1
                                if data[key] =="Мочалка":
                                    b5+=1
                                if data[key] == "Не знаю, что это":
                                    c5+=1
                                a5f= str(a5)
                                b5f=str(b5)
                                c5f=str(c5)
                                
                            if key == 'Как называется этот предмет? ':
                                if data[key] == "Штрих":
                                    a6+=1
                                if data[key] == "Замазка":
                                    b6+=1
                                if data[key] == "Корректор":
                                    c6+=1
                                if data[key] != "Штрих" and data[key] != "Замазка" and data[key] != "Корректор":
                                    d6+=1
                                a6f=str(a6)
                                b6f=str(b6)
                                c6f=str(c6)
                                d6f=str(d6)
                                
                            if key == 'Как называется игра, когда один игрок догоняет других и, посредством тактильного прикосновения, передает статус \"догоняющего\"?':
                                if data[key] == "Ляпки":
                                    a7+=1
                                if data[key] == "Тяпки":
                                    b7+=1
                                if data[key] == "Догонялки":
                                    c7+=1
                                if data[key] != "Ляпки" and data[key] != "Тяпки" and data[key] != "Догонялки":
                                    d7+=1
                                a7f=str(a7)
                                b7f=str(b7)
                                c7f=str(c7)
                                d7f=str(d7)

                            if key == 'Как называется в этом случае \"догоняющий\" игрок?':
                                if data[key] == "Галя":
                                    a8+=1
                                if data[key] == "Догоняла":
                                    b8+=1
                                if data[key] == "Лэм":
                                    c8+=1
                                if data[key] != "Галя" and data[key] != "Догоняла" and data[key] != "Лэм":
                                    d8+=1
                                a8f=str(a8)
                                b8f=str(b8)
                                c8f=str(c8)
                                d8f=str(d8)
                                
                            else:
                                continue
                        
    return render_template('result.html', af=af, bf=bf, cf=cf, df=df, a1f=a1f, b1f=b1f, c1f=c1f, d1f=d1f,a2f=a2f, b2f=b2f, \
                           c2f=c2f, a3f=a3f, b3f=b3f, a4f=a4f, b4f=b4f, c4f=c4f, a5f=a5f, b5f=b5f, c5f=c5f, a6f=a6f, b6f=b6f,c6f=c6f, d6f=d6f, \
                           a7f=a7f, b7f=b7f, c7f=c7f, d7f=d7f, a8f=a8f, b8f=b8f, c8f=c8f, d8f=d8f, cityname = request.args['cityname'])
                    
                
                            
    arr = '\n'.join(arr)
    return render_template('result.html', arr=arr)  

if __name__ == '__main__':
    app.run(port = 5000, debug=True)
